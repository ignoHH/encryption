#ifndef COMMON_H
#define COMMON_H

#include <string>
#include <string.h>
using namespace std;

int *wordKey(string, int[]);
#endif // COMMON_H
